# 🌱 BaseCommons

> **Quadratic Funding on Base** — where many small contributors outweigh a few large ones.

BaseCommons is a production-ready, always-open grant allocation system built for [Base](https://base.org). Projects register on-chain, anyone can donate in ETH, and an admin triggers matching fund distribution using the [quadratic funding formula](https://wtfisqf.com).

---

## Architecture

```
basecommons/
├── packages/
│   ├── foundry/
│   │   ├── contracts/
│   │   │   └── BaseCommons.sol        # Core QF contract
│   │   ├── script/
│   │   │   └── Deploy.s.sol           # Foundry deploy script
│   │   └── test/
│   │       └── BaseCommons.t.sol      # Full test suite
│   └── nextjs/
│       ├── app/
│       │   ├── page.tsx               # Projects grid + hero
│       │   ├── create/page.tsx        # Register a project
│       │   ├── project/[id]/page.tsx  # Project detail + donate
│       │   ├── admin/page.tsx         # Admin: fund pool + distribute
│       │   ├── providers.tsx          # Wagmi + RainbowKit setup
│       │   └── globals.css            # Design system
│       ├── components/
│       │   ├── ProjectCard.tsx        # Grid card component
│       │   ├── DonateBox.tsx          # Donate form + feedback
│       │   ├── MatchEstimator.tsx     # Live QF math visualizer
│       │   └── Nav.tsx                # Sticky navigation
│       ├── constants/
│       │   └── contract.ts            # ABI + contract address
│       ├── hooks/
│       │   └── useBaseCommons.ts      # All contract reads/writes
│       └── scaffold.config.ts         # SE2 chain config
```

---

## Quadratic Funding Formula

For each project `i`, the QF matching share is:

```
match_i = pool × (Σⱼ √donationⱼᵢ)² / Σₖ (Σⱼ √donationⱼₖ)²
```

Where `j` iterates over each unique donor's contribution to project `i`.

**Why this matters:** A project with 100 donors giving 0.001 ETH each receives significantly more matching than a project with 1 donor giving 0.1 ETH — even though the raw donations are equal. Broad community support is rewarded.

**On-chain precision:** We scale amounts by `1e9` before integer square root to retain 9 decimal places of precision in fixed-point arithmetic.

---

## Quick Start

### Prerequisites

- [Node.js](https://nodejs.org) ≥ 18
- [Yarn](https://yarnpkg.com) v1 (classic)
- [Foundry](https://getfoundry.sh/) installed (`foundryup`)

### 1. Install dependencies

```bash
yarn install
```

### 2. Install Foundry dependencies

```bash
cd packages/foundry
forge install foundry-rs/forge-std
```

### 3. Set environment variables

```bash
cp .env.example .env.local
# Edit .env.local with your values
```

### 4. Run locally

```bash
# Terminal 1 — local Anvil chain
yarn workspace @basecommons/foundry chain

# Terminal 2 — deploy to local chain
yarn deploy:local

# Terminal 3 — Next.js dev server
yarn workspace @basecommons/nextjs dev
```

Then update `NEXT_PUBLIC_BASE_COMMONS_ADDRESS` in `.env.local` with the deployed address from Terminal 2.

---

## Deployment to Base

### Base Sepolia (Testnet)

```bash
# Set your deployer key in .env.local
export DEPLOYER_PRIVATE_KEY=0x...
export BASESCAN_API_KEY=your_key

yarn deploy:base-sepolia
```

### Base Mainnet

```bash
yarn deploy:base
```

After deployment, copy the contract address into:
- `.env.local` → `NEXT_PUBLIC_BASE_COMMONS_ADDRESS`

---

## Contract Reference

### State

| Variable | Type | Description |
|---|---|---|
| `admin` | `address` | Admin who can distribute matching funds |
| `projectCount` | `uint256` | Total registered projects |
| `matchingPool` | `uint256` | Current ETH in the matching pool (wei) |
| `cycleId` | `uint256` | Current funding cycle number |

### Key Functions

| Function | Access | Description |
|---|---|---|
| `registerProject(name, desc, imageURI)` | Anyone | Register a new project |
| `donate(projectId)` | Anyone, payable | Donate ETH to a project |
| `fundMatchingPool()` | Anyone, payable | Add ETH to the matching pool |
| `distributeMatching()` | Admin only | Trigger QF distribution + start new cycle |
| `estimateMatching()` | View | Off-chain QF estimate (current state) |

### Events

| Event | Description |
|---|---|
| `ProjectRegistered(projectId, recipient, name, imageURI)` | New project registered |
| `Donation(donor, projectId, amount, cycleId)` | ETH donated to a project |
| `MatchingPoolFunded(funder, amount)` | Matching pool topped up |
| `MatchingDistributed(cycleId, totalPool, projectCount)` | Distribution triggered |
| `MatchingAllocated(cycleId, projectId, amount)` | Per-project match sent |

---

## Testing

```bash
yarn test
# or with gas report:
cd packages/foundry && forge test -vvv --gas-report
```

Test coverage includes:
- Project registration (happy path + reverts)
- Donation tracking (unique donors, amount accumulation, forwarding)
- Matching pool funding (explicit + fallback)
- Distribution (QF math correctness, admin-only, state reset)
- Edge cases (empty pool, zero contributors, large amounts)

---

## Frontend Stack

| Library | Purpose |
|---|---|
| Next.js 14 (App Router) | Framework |
| Wagmi v2 + Viem | Ethereum interactions |
| RainbowKit v2 | Wallet connection UI |
| TanStack Query v5 | Data fetching |

**Design system:** Custom CSS with Fraunces (display) + DM Mono + Plus Jakarta Sans. Earthy commons palette. No component library dependencies.

---

## Scaffold-ETH 2 Integration

This project is built to drop into a Scaffold-ETH 2 monorepo:

1. Copy `packages/foundry/contracts/BaseCommons.sol` into your SE2 `contracts/` folder
2. Copy `packages/nextjs/` pages and components into your SE2 frontend
3. Replace `<ConnectButton>` in `Nav.tsx` with SE2's `<RainbowKitCustomConnectButton />`
4. Use SE2's existing `wagmiConfig` instead of the standalone `providers.tsx`
5. Use SE2's `useDeployedContractInfo` hook instead of the manual ABI import

---

## Roadmap (Next Iterations)

- [ ] **Sybil resistance** — Gitcoin Passport score gating, NFT requirements
- [ ] **Allowlist** — admin approval flow for project registration
- [ ] **Cart UX** — donate to multiple projects in a single transaction
- [ ] **Quadratic voting** — token-weighted governance for cycle parameters
- [ ] **IPFS metadata** — store project metadata off-chain via Filecoin/IPFS
- [ ] **Subgraph** — TheGraph indexer for richer donation history queries
- [ ] **Multi-token** — accept USDC / cbETH in addition to ETH

---

## License

MIT — build freely, fund the commons.

---

*Built with ❤️ for Base · Inspired by [Gitcoin Grants](https://gitcoin.co) · QF formula by [Glen Weyl & Vitalik Buterin](https://wtfisqf.com)*
