// Auto-generated after deployment — replace BASE_COMMONS_ADDRESS with your deployed address
export const BASE_COMMONS_ADDRESS =
  (process.env.NEXT_PUBLIC_BASE_COMMONS_ADDRESS as `0x${string}`) ??
  "0x0000000000000000000000000000000000000000";

export const BASE_COMMONS_ABI = [
  // ── State views ────────────────────────────────────────
  {
    type: "function",
    name: "admin",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "address" }],
  },
  {
    type: "function",
    name: "projectCount",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "matchingPool",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "cycleId",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "projects",
    stateMutability: "view",
    inputs: [{ type: "uint256", name: "projectId" }],
    outputs: [
      { type: "uint256", name: "id" },
      { type: "string",  name: "name" },
      { type: "string",  name: "description" },
      { type: "string",  name: "imageURI" },
      { type: "address", name: "recipient" },
      { type: "bool",    name: "active" },
      { type: "uint256", name: "totalDonations" },
      { type: "uint256", name: "donorCount" },
    ],
  },
  {
    type: "function",
    name: "donorAmounts",
    stateMutability: "view",
    inputs: [
      { type: "uint256", name: "projectId" },
      { type: "address", name: "donor" },
    ],
    outputs: [{ type: "uint256" }],
  },
  {
    type: "function",
    name: "getDonors",
    stateMutability: "view",
    inputs: [{ type: "uint256", name: "projectId" }],
    outputs: [{ type: "address[]" }],
  },
  {
    type: "function",
    name: "getAllProjectIds",
    stateMutability: "view",
    inputs: [],
    outputs: [{ type: "uint256[]", name: "ids" }],
  },
  {
    type: "function",
    name: "estimateMatching",
    stateMutability: "view",
    inputs: [],
    outputs: [
      { type: "uint256[]", name: "ids" },
      { type: "uint256[]", name: "amounts" },
    ],
  },
  // ── Writes ─────────────────────────────────────────────
  {
    type: "function",
    name: "registerProject",
    stateMutability: "nonpayable",
    inputs: [
      { type: "string", name: "name" },
      { type: "string", name: "description" },
      { type: "string", name: "imageURI" },
    ],
    outputs: [{ type: "uint256", name: "projectId" }],
  },
  {
    type: "function",
    name: "donate",
    stateMutability: "payable",
    inputs: [{ type: "uint256", name: "projectId" }],
    outputs: [],
  },
  {
    type: "function",
    name: "fundMatchingPool",
    stateMutability: "payable",
    inputs: [],
    outputs: [],
  },
  {
    type: "function",
    name: "distributeMatching",
    stateMutability: "nonpayable",
    inputs: [],
    outputs: [],
  },
  // ── Events ─────────────────────────────────────────────
  {
    type: "event",
    name: "ProjectRegistered",
    inputs: [
      { type: "uint256", name: "projectId",  indexed: true },
      { type: "address", name: "recipient",  indexed: true },
      { type: "string",  name: "name",       indexed: false },
      { type: "string",  name: "imageURI",   indexed: false },
    ],
  },
  {
    type: "event",
    name: "Donation",
    inputs: [
      { type: "address", name: "donor",     indexed: true },
      { type: "uint256", name: "projectId", indexed: true },
      { type: "uint256", name: "amount",    indexed: false },
      { type: "uint256", name: "cycleId",   indexed: false },
    ],
  },
  {
    type: "event",
    name: "MatchingPoolFunded",
    inputs: [
      { type: "address", name: "funder", indexed: true },
      { type: "uint256", name: "amount", indexed: false },
    ],
  },
  {
    type: "event",
    name: "MatchingDistributed",
    inputs: [
      { type: "uint256", name: "cycleId",      indexed: true },
      { type: "uint256", name: "totalPool",    indexed: false },
      { type: "uint256", name: "projectCount", indexed: false },
    ],
  },
  {
    type: "event",
    name: "MatchingAllocated",
    inputs: [
      { type: "uint256", name: "cycleId",   indexed: true },
      { type: "uint256", name: "projectId", indexed: true },
      { type: "uint256", name: "amount",    indexed: false },
    ],
  },
] as const;
