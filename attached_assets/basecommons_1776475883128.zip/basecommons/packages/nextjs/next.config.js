/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**" },
      { protocol: "http",  hostname: "**" },
    ],
  },
  // Scaffold-ETH 2 uses transpilePackages for wagmi/viem
  transpilePackages: ["@wagmi/core", "wagmi", "viem"],
};

module.exports = nextConfig;
