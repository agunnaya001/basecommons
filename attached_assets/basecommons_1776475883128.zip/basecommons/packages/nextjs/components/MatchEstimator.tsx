"use client";
import { useState, useEffect, useMemo } from "react";
import { formatEther, parseEther } from "viem";
import { sqrtBigInt } from "../hooks/useBaseCommons";
import type { Project } from "../hooks/useBaseCommons";

interface Props {
  projects: Project[];
  focusProjectId: bigint;
  matchingPool: bigint;
}

export default function MatchEstimator({ projects, focusProjectId, matchingPool }: Props) {
  const [donationInput, setDonationInput] = useState("0.001");

  const donationWei = useMemo(() => {
    try { return parseEther(donationInput || "0"); }
    catch { return 0n; }
  }, [donationInput]);

  // Simulate QF with hypothetical donation
  const { before, after } = useMemo(() => {
    const compute = (extraWei: bigint, forProject: bigint) => {
      const sqrtSums = new Map<string, bigint>();
      let totalSqrt = 0n;

      for (const p of projects) {
        let pSqrt = sqrtBigInt(p.totalDonations * BigInt(1e9));
        if (p.id === forProject) pSqrt += sqrtBigInt(extraWei * BigInt(1e9));
        sqrtSums.set(p.id.toString(), pSqrt);
        totalSqrt += pSqrt;
      }

      const result = new Map<string, bigint>();
      if (totalSqrt === 0n) return result;

      for (const p of projects) {
        const s = sqrtSums.get(p.id.toString()) ?? 0n;
        result.set(p.id.toString(), (matchingPool * s * s) / (totalSqrt * totalSqrt));
      }
      return result;
    };

    return {
      before: compute(0n, focusProjectId),
      after:  compute(donationWei, focusProjectId),
    };
  }, [projects, focusProjectId, donationWei, matchingPool]);

  const focusKey     = focusProjectId.toString();
  const matchBefore  = before.get(focusKey) ?? 0n;
  const matchAfter   = after.get(focusKey)  ?? 0n;
  const matchDelta   = matchAfter - matchBefore;

  const fmtEth = (v: bigint) => parseFloat(formatEther(v)).toFixed(5);

  // Bar chart data — top 5 projects by match change
  const bars = projects.slice(0, 6).map((p) => {
    const b = before.get(p.id.toString()) ?? 0n;
    const a = after.get(p.id.toString())  ?? 0n;
    return { id: p.id, name: p.name, before: b, after: a, isFocus: p.id === focusProjectId };
  });

  const maxMatch = bars.reduce((m, b) => b.after > m ? b.after : m, 1n);

  return (
    <div style={{
      background: "var(--ink)", color: "var(--paper)",
      borderRadius: "var(--r-lg)", padding: 28, position: "relative", overflow: "hidden",
    }}>
      {/* Decorative glow */}
      <div style={{
        position: "absolute", top: -60, right: -60, width: 200, height: 200,
        background: "radial-gradient(circle, rgba(200,151,42,0.3) 0%, transparent 70%)",
        pointerEvents: "none",
      }} />

      <div style={{ marginBottom: 20, position: "relative" }}>
        <h3 style={{
          fontFamily: "var(--font-display)", fontSize: "1.3rem",
          fontWeight: 700, marginBottom: 4,
        }}>
          Live Match Estimator ✦
        </h3>
        <p style={{ fontSize: 13, color: "rgba(250,247,240,0.6)" }}>
          See how your donation shifts the quadratic matching
        </p>
      </div>

      {/* Input */}
      <div style={{ marginBottom: 24, position: "relative" }}>
        <label style={{
          display: "block", fontSize: 12, fontFamily: "var(--font-mono)",
          textTransform: "uppercase", letterSpacing: "0.08em",
          color: "rgba(250,247,240,0.5)", marginBottom: 8,
        }}>
          If you donate…
        </label>
        <div style={{ position: "relative" }}>
          <input
            type="number"
            step="0.001"
            min="0"
            value={donationInput}
            onChange={(e) => setDonationInput(e.target.value)}
            style={{
              width: "100%",
              padding: "14px 60px 14px 16px",
              background: "rgba(255,255,255,0.07)",
              border: "1.5px solid rgba(200,151,42,0.4)",
              borderRadius: "var(--r)",
              color: "var(--paper)",
              fontFamily: "var(--font-mono)",
              fontSize: 18,
              fontWeight: 600,
              outline: "none",
            }}
            onFocus={(e) => { e.target.style.borderColor = "var(--gold)"; e.target.style.boxShadow = "0 0 0 3px rgba(200,151,42,0.2)"; }}
            onBlur={(e)  => { e.target.style.borderColor = "rgba(200,151,42,0.4)"; e.target.style.boxShadow = "none"; }}
          />
          <span style={{
            position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)",
            fontFamily: "var(--font-mono)", fontSize: 14,
            color: "rgba(250,247,240,0.5)",
          }}>
            ETH
          </span>
        </div>
      </div>

      {/* Match delta highlight */}
      <div style={{
        background: "rgba(200,151,42,0.12)", border: "1px solid rgba(200,151,42,0.3)",
        borderRadius: "var(--r)", padding: "16px 20px", marginBottom: 24,
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "rgba(250,247,240,0.5)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 4 }}>
            This project&apos;s match
          </div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "1.8rem", fontWeight: 800, color: "var(--gold)" }}>
            {fmtEth(matchAfter)} ETH
          </div>
        </div>
        {matchDelta > 0n && (
          <div style={{
            background: "rgba(90,122,90,0.3)", borderRadius: "var(--r)",
            padding: "8px 14px", textAlign: "center",
          }}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--sage-light)" }}>
              +{fmtEth(matchDelta)} ETH
            </span>
            <br />
            <span style={{ fontSize: 11, color: "rgba(250,247,240,0.5)" }}>additional match</span>
          </div>
        )}
      </div>

      {/* Visualization bars */}
      {bars.length > 0 && (
        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "rgba(250,247,240,0.4)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>
            Distribution preview
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {bars.map((b) => {
              const pct = maxMatch > 0n ? Number((b.after * 1000n) / maxMatch) / 10 : 0;
              const prevPct = maxMatch > 0n ? Number((b.before * 1000n) / maxMatch) / 10 : 0;
              return (
                <div key={b.id.toString()}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                    <span style={{
                      fontSize: 12, color: b.isFocus ? "var(--gold)" : "rgba(250,247,240,0.7)",
                      fontWeight: b.isFocus ? 600 : 400,
                    }}>
                      {b.isFocus ? "▶ " : ""}{b.name.length > 20 ? b.name.slice(0, 20) + "…" : b.name}
                    </span>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "rgba(250,247,240,0.5)" }}>
                      {fmtEth(b.after)}
                    </span>
                  </div>
                  <div style={{ position: "relative", height: 6, background: "rgba(255,255,255,0.08)", borderRadius: 3 }}>
                    {/* Previous bar */}
                    <div style={{
                      position: "absolute", left: 0, top: 0, height: "100%",
                      width: `${prevPct}%`, borderRadius: 3,
                      background: "rgba(255,255,255,0.15)",
                      transition: "width 0.3s ease",
                    }} />
                    {/* New bar */}
                    <div style={{
                      position: "absolute", left: 0, top: 0, height: "100%",
                      width: `${pct}%`, borderRadius: 3,
                      background: b.isFocus
                        ? "linear-gradient(90deg, var(--gold), var(--gold-light))"
                        : "rgba(138,170,122,0.6)",
                      transition: "width 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)",
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* QF formula explainer */}
      <div style={{
        marginTop: 24, paddingTop: 20, borderTop: "1px solid rgba(255,255,255,0.08)",
        fontSize: 12, color: "rgba(250,247,240,0.4)", lineHeight: 1.6,
      }}>
        <span style={{ fontFamily: "var(--font-mono)" }}>
          match ∝ (Σ√donations)² · pool / Σⱼ(Σ√donationsⱼ)²
        </span>
      </div>
    </div>
  );
}
