"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

// Scaffold-ETH provides <ConnectButton> via RainbowKit — import from there in your SE2 setup
// This is a placeholder wrapper; replace with your SE2 <RainbowKitCustomConnectButton />
function ConnectButton() {
  return (
    <div id="connect-button-slot">
      {/* Scaffold-ETH 2: replace with <RainbowKitCustomConnectButton /> */}
      <button className="btn btn-primary" style={{ fontSize: 14, padding: "10px 20px" }}>
        Connect Wallet
      </button>
    </div>
  );
}

export default function Nav() {
  const path = usePathname();
  const links = [
    { href: "/",       label: "Projects" },
    { href: "/create", label: "Submit Project" },
    { href: "/admin",  label: "Admin" },
  ];

  return (
    <nav className="nav">
      <div className="nav-inner">
        <Link href="/" className="nav-logo">
          Base<span>Commons</span>
        </Link>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              style={{
                padding: "8px 14px",
                borderRadius: "var(--r)",
                fontSize: 14,
                fontWeight: path === l.href ? 600 : 400,
                color: path === l.href ? "var(--ink)" : "var(--slate)",
                background: path === l.href ? "var(--mist)" : "transparent",
                textDecoration: "none",
                transition: "all 0.15s",
              }}
            >
              {l.label}
            </Link>
          ))}
          <div style={{ marginLeft: 8 }}>
            <ConnectButton />
          </div>
        </div>
      </div>
    </nav>
  );
}
