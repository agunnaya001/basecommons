"use client";
import Link from "next/link";
import { formatEther } from "viem";
import type { Project } from "../hooks/useBaseCommons";

interface Props {
  project: Project;
  rank?: number;
}

const PLACEHOLDER = "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=600&q=80";

export default function ProjectCard({ project, rank }: Props) {
  const imgSrc = project.imageURI?.startsWith("http") ? project.imageURI : PLACEHOLDER;
  const raised  = parseFloat(formatEther(project.totalDonations)).toFixed(4);
  const matched = parseFloat(formatEther(project.estimatedMatch ?? 0n)).toFixed(4);

  return (
    <Link href={`/project/${project.id}`} style={{ textDecoration: "none" }}>
      <article className="card" style={{ height: "100%", display: "flex", flexDirection: "column" }}>
        {/* Image */}
        <div style={{ position: "relative", height: 200, overflow: "hidden", background: "var(--mist)" }}>
          <img
            src={imgSrc}
            alt={project.name}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            onError={(e) => { (e.target as HTMLImageElement).src = PLACEHOLDER; }}
          />
          {rank && rank <= 3 && (
            <div style={{
              position: "absolute", top: 12, left: 12,
              background: "var(--gold)", color: "var(--ink)",
              borderRadius: "100px", padding: "4px 12px",
              fontFamily: "var(--font-mono)", fontSize: 12, fontWeight: 600,
            }}>
              #{rank} Top Funded
            </div>
          )}
          <div style={{
            position: "absolute", bottom: 0, left: 0, right: 0, height: 60,
            background: "linear-gradient(transparent, rgba(26,18,8,0.5))",
          }} />
        </div>

        {/* Body */}
        <div style={{ padding: "20px", flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
          <div>
            <h3 style={{
              fontFamily: "var(--font-display)", fontSize: "1.25rem",
              fontWeight: 700, color: "var(--ink)", marginBottom: 6,
            }}>
              {project.name}
            </h3>
            <p style={{
              color: "var(--slate)", fontSize: "0.9rem", lineHeight: 1.5,
              display: "-webkit-box", WebkitLineClamp: 2,
              WebkitBoxOrient: "vertical", overflow: "hidden",
            }}>
              {project.description}
            </p>
          </div>

          {/* Metrics */}
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
            gap: 8, paddingTop: 12,
            borderTop: "1px solid var(--mist)", marginTop: "auto",
          }}>
            <Metric label="Raised" value={`${raised} ETH`} />
            <Metric label="Donors" value={project.donorCount.toString()} accent />
            <Metric label="Est. Match" value={`${matched} ETH`} gold />
          </div>
        </div>
      </article>
    </Link>
  );
}

function Metric({ label, value, accent, gold }: { label: string; value: string; accent?: boolean; gold?: boolean }) {
  return (
    <div style={{ textAlign: "center" }}>
      <span style={{
        display: "block",
        fontFamily: "var(--font-mono)", fontSize: "0.85rem", fontWeight: 600,
        color: gold ? "var(--gold)" : accent ? "var(--sage)" : "var(--ink)",
      }}>
        {value}
      </span>
      <span style={{
        display: "block", fontSize: "0.7rem", color: "var(--slate)",
        textTransform: "uppercase", letterSpacing: "0.06em", marginTop: 2,
      }}>
        {label}
      </span>
    </div>
  );
}
