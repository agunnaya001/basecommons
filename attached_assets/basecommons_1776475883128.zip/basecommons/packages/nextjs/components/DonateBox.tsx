"use client";
import { useState } from "react";
import { useBaseCommons } from "../hooks/useBaseCommons";

interface Props {
  projectId: bigint;
  projectName: string;
  onSuccess?: () => void;
}

export default function DonateBox({ projectId, projectName, onSuccess }: Props) {
  const { donate, txPending, userAddress } = useBaseCommons();
  const [amount, setAmount] = useState("");
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [txHash, setTxHash] = useState<string | null>(null);

  const PRESETS = ["0.001", "0.005", "0.01", "0.05"];

  async function handleDonate() {
    if (!amount || parseFloat(amount) <= 0) return;
    setStatus("idle");
    try {
      const hash = await donate(projectId, amount);
      setTxHash(hash);
      setStatus("success");
      setAmount("");
      onSuccess?.();
    } catch (e: any) {
      console.error(e);
      setStatus("error");
    }
  }

  if (!userAddress) {
    return (
      <div style={{
        background: "var(--cream)", border: "1.5px dashed var(--mist)",
        borderRadius: "var(--r-lg)", padding: 28, textAlign: "center",
      }}>
        <p style={{ color: "var(--slate)", marginBottom: 12 }}>Connect your wallet to donate</p>
        <p style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--slate)" }}>
          Use the wallet button in the top-right corner
        </p>
      </div>
    );
  }

  return (
    <div style={{
      background: "var(--cream)", border: "1.5px solid var(--mist)",
      borderRadius: "var(--r-lg)", padding: 28,
    }}>
      <h3 style={{
        fontFamily: "var(--font-display)", fontSize: "1.4rem",
        fontWeight: 700, marginBottom: 20,
      }}>
        Support <em style={{ fontStyle: "italic", color: "var(--gold)" }}>{projectName}</em>
      </h3>

      {/* Presets */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
        {PRESETS.map((p) => (
          <button
            key={p}
            onClick={() => setAmount(p)}
            className="btn btn-secondary"
            style={{
              padding: "8px 16px", fontSize: 13,
              background: amount === p ? "var(--glow)" : undefined,
              borderColor: amount === p ? "var(--gold)" : undefined,
            }}
          >
            {p} ETH
          </button>
        ))}
      </div>

      {/* Custom amount */}
      <div style={{ position: "relative", marginBottom: 16 }}>
        <input
          className="input"
          type="number"
          step="0.0001"
          min="0"
          placeholder="Custom amount in ETH"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{ paddingRight: 60 }}
        />
        <span style={{
          position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)",
          fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--slate)",
        }}>
          ETH
        </span>
      </div>

      <button
        className="btn btn-primary"
        style={{ width: "100%", justifyContent: "center", fontSize: 16 }}
        onClick={handleDonate}
        disabled={txPending || !amount || parseFloat(amount) <= 0}
      >
        {txPending ? (
          <>
            <Spinner />
            Broadcasting…
          </>
        ) : (
          <>
            ✦ Donate {amount || "—"} ETH
          </>
        )}
      </button>

      {/* Feedback */}
      {status === "success" && (
        <div style={{
          marginTop: 16, padding: "12px 16px",
          background: "rgba(90,122,90,0.12)", border: "1px solid rgba(90,122,90,0.3)",
          borderRadius: "var(--r)", fontSize: 14,
        }}>
          🌱 Donation confirmed!{" "}
          {txHash && (
            <a
              href={`https://basescan.org/tx/${txHash}`}
              target="_blank"
              rel="noreferrer"
              style={{ color: "var(--sage)", textDecoration: "underline" }}
            >
              View on Basescan
            </a>
          )}
        </div>
      )}
      {status === "error" && (
        <div style={{
          marginTop: 16, padding: "12px 16px",
          background: "rgba(196,92,48,0.1)", border: "1px solid rgba(196,92,48,0.3)",
          borderRadius: "var(--r)", fontSize: 14, color: "var(--terracotta)",
        }}>
          Transaction failed — check your wallet and try again.
        </div>
      )}
    </div>
  );
}

function Spinner() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" style={{ animation: "spin-slow 1s linear infinite" }}>
      <circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="28" strokeDashoffset="10" />
    </svg>
  );
}
