import { defineChain } from "viem";
import * as chains from "viem/chains";

/**
 * BaseCommons scaffold.config.ts
 *
 * This file follows the Scaffold-ETH 2 configuration convention.
 * If using the full SE2 scaffold, this replaces the default scaffold.config.ts.
 *
 * @see https://docs.scaffoldeth.io/deploying-your-contract
 */
export type ScaffoldConfig = {
  targetNetworks: readonly chains.Chain[];
  pollingInterval: number;
  alchemyApiKey: string;
  walletConnectProjectId: string;
  onlyLocalBurnerWallet: boolean;
};

const scaffoldConfig = {
  // Target Base mainnet; switch to chains.baseSepolia for testnet development
  targetNetworks: [chains.base, chains.baseSepolia],

  // Poll interval for the frontend (ms)
  pollingInterval: 30000,

  // Alchemy key (used by SE2 internally)
  alchemyApiKey: process.env.NEXT_PUBLIC_ALCHEMY_API_KEY ?? "oKxs-03sij-U_N0iOlrSsZFr29-IqbuF",

  // WalletConnect project ID — required for WalletConnect v2
  walletConnectProjectId: process.env.NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID ?? "",

  // Only allow burner wallets on local network (dev convenience)
  onlyLocalBurnerWallet: false,
} as const satisfies ScaffoldConfig;

export default scaffoldConfig;
