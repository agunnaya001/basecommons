"use client";
import Link from "next/link";
import { formatEther } from "viem";
import { useBaseCommons } from "../hooks/useBaseCommons";
import ProjectCard from "../components/ProjectCard";

export default function Home() {
  const { projects, matchingPool, cycleId, loading } = useBaseCommons();

  const totalDonated = projects.reduce((s, p) => s + p.totalDonations, 0n);
  const totalDonors  = projects.reduce((s, p) => s + p.donorCount, 0n);
  const fmtEth = (v: bigint) => parseFloat(formatEther(v)).toFixed(4);

  // Sort by estimated match (most matched first)
  const sorted = [...projects].sort((a, b) =>
    (b.estimatedMatch ?? 0n) > (a.estimatedMatch ?? 0n) ? 1 : -1
  );

  return (
    <>
      {/* Hero */}
      <section className="hero">
        <div className="container">
          <p className="fade-up" style={{
            fontFamily: "var(--font-mono)", fontSize: 12,
            textTransform: "uppercase", letterSpacing: "0.12em",
            color: "var(--sage)", marginBottom: 16,
          }}>
            ✦ Quadratic Funding · Built on Base
          </p>
          <h1 className="fade-up fade-up-delay-1">
            Fund what <em>matters</em>,<br />
            not just who<br />
            <em>shouts loudest</em>
          </h1>
          <p className="fade-up fade-up-delay-2">
            BaseCommons distributes a matching pool using quadratic funding —
            where many small donors unlock more match than a few large ones.
          </p>
          <div className="fade-up fade-up-delay-3" style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            <Link href="/create" className="btn btn-primary" style={{ fontSize: 16 }}>
              Submit a Project ✦
            </Link>
            <a
              href="https://wtfisqf.com"
              target="_blank"
              rel="noreferrer"
              className="btn btn-secondary"
            >
              What is QF?
            </a>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <div className="container">
        <div className="stats-bar fade-up fade-up-delay-3">
          <div className="stat-item">
            <span className="stat-value">{projects.length}</span>
            <span className="stat-label">Projects</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{totalDonors.toString()}</span>
            <span className="stat-label">Unique Donors</span>
          </div>
          <div className="stat-item">
            <span className="stat-value">{fmtEth(totalDonated)}</span>
            <span className="stat-label">ETH Raised</span>
          </div>
          <div className="stat-item" style={{ background: "var(--glow)" }}>
            <span className="stat-value" style={{ color: "var(--gold)" }}>
              {fmtEth(matchingPool)}
            </span>
            <span className="stat-label">Matching Pool</span>
          </div>
        </div>

        {/* Cycle badge */}
        <p style={{
          textAlign: "center", marginBottom: 40,
          fontFamily: "var(--font-mono)", fontSize: 12,
          color: "var(--slate)",
        }}>
          Funding Cycle #{cycleId.toString()} · Pool distributes when admin triggers
        </p>

        {/* Projects grid */}
        {loading ? (
          <div className="projects-grid">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card" style={{ height: 360 }}>
                <div className="skeleton" style={{ height: 200 }} />
                <div style={{ padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
                  <div className="skeleton" style={{ height: 24, width: "60%" }} />
                  <div className="skeleton" style={{ height: 16, width: "90%" }} />
                  <div className="skeleton" style={{ height: 16, width: "75%" }} />
                </div>
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div style={{
            textAlign: "center", padding: "80px 24px",
            border: "2px dashed var(--mist)", borderRadius: "var(--r-lg)",
          }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>🌱</div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.8rem", marginBottom: 12 }}>
              Be the first to plant a seed
            </h2>
            <p style={{ color: "var(--slate)", marginBottom: 24 }}>
              No projects registered yet. Submit yours to start the commons.
            </p>
            <Link href="/create" className="btn btn-primary">
              Submit a Project
            </Link>
          </div>
        ) : (
          <div className="projects-grid" style={{ paddingBottom: 80 }}>
            {sorted.map((p, i) => (
              <ProjectCard key={p.id.toString()} project={p} rank={i + 1} />
            ))}
          </div>
        )}
      </div>
    </>
  );
}
