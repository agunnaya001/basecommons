"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { formatEther } from "viem";
import { useBaseCommons, type Project, type DonationEvent } from "../../../hooks/useBaseCommons";
import DonateBox from "../../../components/DonateBox";
import MatchEstimator from "../../../components/MatchEstimator";

const PLACEHOLDER = "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200&q=80";

function shortAddr(a: string) { return `${a.slice(0, 6)}…${a.slice(-4)}`; }
function fmtEth(v: bigint) { return parseFloat(formatEther(v)).toFixed(5); }
function timeAgo(blockNum: bigint) { return `Block #${blockNum.toString()}`; }

export default function ProjectDetail() {
  const params = useParams();
  const id     = BigInt(params.id as string);

  const { projects, matchingPool, getDonationEvents, loading, refresh } = useBaseCommons();

  const [donations, setDonations] = useState<DonationEvent[]>([]);
  const [eventsLoading, setEventsLoading] = useState(true);

  const project: Project | undefined = projects.find((p) => p.id === id);

  useEffect(() => {
    (async () => {
      setEventsLoading(true);
      const evts = await getDonationEvents(id);
      setDonations(evts.reverse()); // newest first
      setEventsLoading(false);
    })();
  }, [id, projects.length]);

  if (loading && !project) {
    return (
      <div className="container" style={{ paddingTop: 60 }}>
        <div className="skeleton" style={{ height: 320, borderRadius: "var(--r-lg)", marginBottom: 32 }} />
        <div className="skeleton" style={{ height: 48, width: "50%", marginBottom: 16 }} />
        <div className="skeleton" style={{ height: 24, width: "80%" }} />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="container" style={{ paddingTop: 80, textAlign: "center" }}>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "2rem", marginBottom: 16 }}>
          Project not found
        </h2>
        <Link href="/" className="btn btn-secondary">← Back to projects</Link>
      </div>
    );
  }

  const imgSrc = project.imageURI?.startsWith("http") ? project.imageURI : PLACEHOLDER;

  return (
    <div style={{ paddingBottom: 80 }}>
      {/* Hero image */}
      <div style={{ position: "relative", height: "clamp(240px, 35vw, 420px)", overflow: "hidden", background: "var(--mist)" }}>
        <img
          src={imgSrc}
          alt={project.name}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
          onError={(e) => { (e.target as HTMLImageElement).src = PLACEHOLDER; }}
        />
        <div style={{
          position: "absolute", inset: 0,
          background: "linear-gradient(to bottom, transparent 40%, rgba(26,18,8,0.7) 100%)",
        }} />
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, padding: "0 24px 32px" }}>
          <div className="container">
            <Link href="/" style={{
              fontFamily: "var(--font-mono)", fontSize: 12, color: "rgba(250,247,240,0.7)",
              textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 4,
              marginBottom: 12,
            }}>
              ← All projects
            </Link>
            <h1 style={{
              fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3.5rem)",
              fontWeight: 800, color: "white", lineHeight: 1.1,
            }}>
              {project.name}
            </h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container" style={{ paddingTop: 40 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr min(400px, 40%)", gap: 40, alignItems: "start" }}>

          {/* Left column */}
          <div>
            {/* Metrics */}
            <div style={{
              display: "grid", gridTemplateColumns: "repeat(3, 1fr)",
              gap: 1, background: "var(--mist)", borderRadius: "var(--r-lg)",
              overflow: "hidden", marginBottom: 32,
            }}>
              {[
                { label: "Total Raised", value: `${fmtEth(project.totalDonations)} ETH`, color: "var(--ink)" },
                { label: "Unique Donors", value: project.donorCount.toString(), color: "var(--sage)" },
                { label: "Est. Match", value: `${fmtEth(project.estimatedMatch ?? 0n)} ETH`, color: "var(--gold)" },
              ].map((m) => (
                <div key={m.label} style={{ background: "var(--cream)", padding: "20px 16px", textAlign: "center" }}>
                  <span style={{
                    display: "block",
                    fontFamily: "var(--font-mono)", fontSize: "1.1rem", fontWeight: 600,
                    color: m.color,
                  }}>
                    {m.value}
                  </span>
                  <span style={{ fontSize: 11, color: "var(--slate)", textTransform: "uppercase", letterSpacing: "0.07em" }}>
                    {m.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Description */}
            <div style={{ marginBottom: 32 }}>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.4rem", marginBottom: 12 }}>
                About this project
              </h2>
              <p style={{ color: "var(--slate)", lineHeight: 1.7 }}>
                {project.description || "No description provided."}
              </p>
            </div>

            {/* Recipient */}
            <div style={{
              background: "var(--cream)", border: "1.5px solid var(--mist)",
              borderRadius: "var(--r)", padding: "14px 18px", marginBottom: 32,
            }}>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate)", textTransform: "uppercase", letterSpacing: "0.08em", display: "block", marginBottom: 4 }}>
                Recipient wallet
              </span>
              <a
                href={`https://basescan.org/address/${project.recipient}`}
                target="_blank"
                rel="noreferrer"
                style={{ fontFamily: "var(--font-mono)", color: "var(--sage)", fontSize: 14, wordBreak: "break-all" }}
              >
                {project.recipient}
              </a>
            </div>

            {/* Donation history */}
            <div>
              <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.4rem", marginBottom: 16 }}>
                Donation History
              </h2>

              {eventsLoading ? (
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="skeleton" style={{ height: 60, borderRadius: "var(--r)" }} />
                  ))}
                </div>
              ) : donations.length === 0 ? (
                <div style={{
                  padding: "32px 24px", textAlign: "center",
                  background: "var(--cream)", border: "1.5px dashed var(--mist)",
                  borderRadius: "var(--r-lg)",
                }}>
                  <p style={{ color: "var(--slate)" }}>No donations yet — be the first! 🌱</p>
                </div>
              ) : (
                <div style={{
                  display: "flex", flexDirection: "column", gap: 2,
                  maxHeight: 400, overflowY: "auto",
                  borderRadius: "var(--r-lg)", border: "1.5px solid var(--mist)",
                }}>
                  {donations.map((d, i) => (
                    <div
                      key={d.transactionHash + i}
                      style={{
                        display: "flex", alignItems: "center", justifyContent: "space-between",
                        padding: "14px 18px",
                        background: i % 2 === 0 ? "var(--cream)" : "white",
                        gap: 12,
                      }}
                    >
                      <div>
                        <a
                          href={`https://basescan.org/address/${d.donor}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{ fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--sage)", textDecoration: "none" }}
                        >
                          {shortAddr(d.donor)}
                        </a>
                        <span style={{ display: "block", fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate)", marginTop: 2 }}>
                          {timeAgo(d.blockNumber)} · Cycle #{d.cycleId.toString()}
                        </span>
                      </div>
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, fontWeight: 600, color: "var(--ink)", whiteSpace: "nowrap" }}>
                        {fmtEth(d.amount)} ETH
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right column — sticky donate + estimator */}
          <div style={{ display: "flex", flexDirection: "column", gap: 24, position: "sticky", top: 80 }}>
            <DonateBox
              projectId={project.id}
              projectName={project.name}
              onSuccess={refresh}
            />
            <MatchEstimator
              projects={projects}
              focusProjectId={project.id}
              matchingPool={matchingPool}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
