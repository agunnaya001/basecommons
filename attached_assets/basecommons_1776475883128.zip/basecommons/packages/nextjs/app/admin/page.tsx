"use client";
import { useState } from "react";
import { formatEther } from "viem";
import { useBaseCommons } from "../../hooks/useBaseCommons";
import { BASE_COMMONS_ADDRESS } from "../../constants/contract";

function fmtEth(v: bigint) { return parseFloat(formatEther(v)).toFixed(5); }

export default function AdminPage() {
  const {
    projects, matchingPool, cycleId,
    userAddress, loading,
    fundMatchingPool, distributeMatching, txPending,
  } = useBaseCommons();

  const [fundAmount, setFundAmount] = useState("1");
  const [status, setStatus]         = useState<Record<string, string>>({});

  function setMsg(key: string, msg: string) {
    setStatus((s) => ({ ...s, [key]: msg }));
  }

  async function handleFund() {
    setMsg("fund", "");
    try {
      const hash = await fundMatchingPool(fundAmount);
      setMsg("fund", `✅ Funded! tx: ${hash?.slice(0, 10)}…`);
    } catch (e: any) {
      setMsg("fund", `❌ ${e.message}`);
    }
  }

  async function handleDistribute() {
    if (!confirm("Trigger matching distribution? This will reset the current cycle.")) return;
    setMsg("dist", "");
    try {
      const hash = await distributeMatching();
      setMsg("dist", `✅ Distributed! tx: ${hash?.slice(0, 10)}…`);
    } catch (e: any) {
      setMsg("dist", `❌ ${e.message}`);
    }
  }

  // Sort projects by estimated match
  const sorted = [...projects].sort(
    (a, b) => ((b.estimatedMatch ?? 0n) > (a.estimatedMatch ?? 0n) ? 1 : -1)
  );

  return (
    <div className="container" style={{ paddingTop: 60, paddingBottom: 80, maxWidth: 900 }}>
      {/* Header */}
      <div style={{ marginBottom: 40 }}>
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: 12,
          textTransform: "uppercase", letterSpacing: "0.1em",
          color: "var(--terracotta)",
        }}>
          ✦ Admin Panel
        </span>
        <h1 style={{
          fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3rem)",
          fontWeight: 800, marginTop: 8,
        }}>
          Matching Pool Control
        </h1>
        <p style={{ color: "var(--slate)", marginTop: 8 }}>
          Fund the pool and trigger distributions. Only the admin wallet can distribute.
        </p>
      </div>

      {/* Connected address warning */}
      {userAddress && (
        <div style={{
          background: "var(--cream)", border: "1.5px solid var(--mist)",
          borderRadius: "var(--r)", padding: "12px 18px", marginBottom: 24,
          fontFamily: "var(--font-mono)", fontSize: 13,
        }}>
          Connected: <span style={{ color: "var(--sage)" }}>{userAddress}</span>
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 40 }}>
        {/* Matching pool stat */}
        <div style={{
          background: "var(--ink)", color: "var(--paper)",
          borderRadius: "var(--r-lg)", padding: 32,
        }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "rgba(250,247,240,0.5)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            Current Pool
          </span>
          <div style={{
            fontFamily: "var(--font-display)", fontSize: "2.8rem",
            fontWeight: 800, color: "var(--gold)", marginTop: 8,
          }}>
            {fmtEth(matchingPool)}
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, color: "rgba(250,247,240,0.5)", marginTop: 4 }}>
            ETH available to distribute
          </div>
          <div style={{ marginTop: 16, fontSize: 13, color: "rgba(250,247,240,0.4)" }}>
            Contract: {BASE_COMMONS_ADDRESS.slice(0, 10)}…
          </div>
        </div>

        {/* Cycle stat */}
        <div style={{
          background: "var(--cream)", border: "1.5px solid var(--mist)",
          borderRadius: "var(--r-lg)", padding: 32,
        }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            Cycle Info
          </span>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "2.8rem", fontWeight: 800, marginTop: 8 }}>
            #{cycleId.toString()}
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 14, color: "var(--slate)", marginTop: 4 }}>
            Current funding cycle
          </div>
          <div style={{ marginTop: 16, fontSize: 13, color: "var(--slate)" }}>
            {projects.length} active projects · {projects.reduce((s, p) => s + p.donorCount, 0n).toString()} donors
          </div>
        </div>
      </div>

      {/* Fund Pool */}
      <section style={{
        background: "var(--cream)", border: "1.5px solid var(--mist)",
        borderRadius: "var(--r-lg)", padding: 32, marginBottom: 24,
      }}>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 700, marginBottom: 20 }}>
          Fund the Matching Pool
        </h2>
        <div style={{ display: "flex", gap: 12, alignItems: "flex-end" }}>
          <div style={{ flex: 1 }}>
            <label style={{
              display: "block", fontFamily: "var(--font-mono)", fontSize: 11,
              textTransform: "uppercase", letterSpacing: "0.08em",
              color: "var(--slate)", marginBottom: 8,
            }}>
              Amount (ETH)
            </label>
            <input
              className="input"
              type="number"
              step="0.01"
              min="0"
              value={fundAmount}
              onChange={(e) => setFundAmount(e.target.value)}
            />
          </div>
          <button
            className="btn btn-primary"
            onClick={handleFund}
            disabled={txPending || !fundAmount || parseFloat(fundAmount) <= 0}
            style={{ whiteSpace: "nowrap" }}
          >
            {txPending ? "Broadcasting…" : "Add to Pool"}
          </button>
        </div>
        {status.fund && (
          <p style={{ marginTop: 12, fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--sage)" }}>
            {status.fund}
          </p>
        )}
        <p style={{ marginTop: 12, fontSize: 13, color: "var(--slate)" }}>
          Anyone can add to the pool. Only admin can distribute.
        </p>
      </section>

      {/* Distribute */}
      <section style={{
        background: "var(--ink)", color: "var(--paper)",
        borderRadius: "var(--r-lg)", padding: 32, marginBottom: 40,
      }}>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 700, marginBottom: 8 }}>
          Distribute Matching Funds
        </h2>
        <p style={{ color: "rgba(250,247,240,0.6)", marginBottom: 20, fontSize: 14 }}>
          This will calculate QF shares, send matching ETH to all project recipients,
          and start a new cycle. This action is irreversible.
        </p>
        <button
          className="btn btn-danger"
          onClick={handleDistribute}
          disabled={txPending || matchingPool === 0n}
          style={{ fontSize: 16 }}
        >
          {txPending ? "Broadcasting…" : `Distribute ${fmtEth(matchingPool)} ETH Now ✦`}
        </button>
        {status.dist && (
          <p style={{ marginTop: 12, fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--sage-light)" }}>
            {status.dist}
          </p>
        )}
        {matchingPool === 0n && (
          <p style={{ marginTop: 12, fontSize: 13, color: "rgba(250,247,240,0.4)" }}>
            Pool is empty — fund it before distributing.
          </p>
        )}
      </section>

      {/* Distribution preview */}
      <section>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 700, marginBottom: 20 }}>
          Distribution Preview
        </h2>
        <p style={{ color: "var(--slate)", fontSize: 14, marginBottom: 20 }}>
          Estimated matching amounts if distribution were triggered now, ranked by QF score.
        </p>

        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[1, 2, 3].map((i) => (
              <div key={i} className="skeleton" style={{ height: 64, borderRadius: "var(--r)" }} />
            ))}
          </div>
        ) : sorted.length === 0 ? (
          <p style={{ color: "var(--slate)", fontStyle: "italic" }}>No projects registered.</p>
        ) : (
          <div style={{
            border: "1.5px solid var(--mist)", borderRadius: "var(--r-lg)", overflow: "hidden",
          }}>
            {/* Header */}
            <div style={{
              display: "grid", gridTemplateColumns: "40px 1fr repeat(4, 120px)",
              padding: "12px 20px",
              background: "var(--mist)",
              fontFamily: "var(--font-mono)", fontSize: 11,
              textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--slate)",
            }}>
              <span>#</span>
              <span>Project</span>
              <span style={{ textAlign: "right" }}>Raised</span>
              <span style={{ textAlign: "right" }}>Donors</span>
              <span style={{ textAlign: "right" }}>Est. Match</span>
              <span style={{ textAlign: "right" }}>% of Pool</span>
            </div>
            {sorted.map((p, i) => {
              const matchPct = matchingPool > 0n
                ? Number(((p.estimatedMatch ?? 0n) * 10000n) / matchingPool) / 100
                : 0;
              return (
                <div
                  key={p.id.toString()}
                  style={{
                    display: "grid", gridTemplateColumns: "40px 1fr repeat(4, 120px)",
                    padding: "16px 20px",
                    background: i % 2 === 0 ? "var(--cream)" : "white",
                    borderTop: "1px solid var(--mist)",
                    alignItems: "center",
                  }}
                >
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--slate)" }}>
                    {i + 1}
                  </span>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
                    <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate)" }}>
                      {p.recipient.slice(0, 10)}…
                    </div>
                  </div>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, textAlign: "right" }}>
                    {fmtEth(p.totalDonations)}
                  </span>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, textAlign: "right", color: "var(--sage)" }}>
                    {p.donorCount.toString()}
                  </span>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 13, textAlign: "right", color: "var(--gold)", fontWeight: 600 }}>
                    {fmtEth(p.estimatedMatch ?? 0n)}
                  </span>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 8 }}>
                    <div style={{ height: 6, width: 60, background: "var(--mist)", borderRadius: 3 }}>
                      <div style={{
                        height: "100%",
                        width: `${Math.min(matchPct, 100)}%`,
                        background: "var(--gold)",
                        borderRadius: 3,
                      }} />
                    </div>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--slate)", minWidth: 36, textAlign: "right" }}>
                      {matchPct.toFixed(1)}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
