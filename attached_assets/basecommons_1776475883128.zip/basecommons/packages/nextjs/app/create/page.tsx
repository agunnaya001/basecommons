"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useBaseCommons } from "../../hooks/useBaseCommons";

export default function CreatePage() {
  const router = useRouter();
  const { registerProject, txPending, userAddress } = useBaseCommons();

  const [form, setForm] = useState({ name: "", description: "", imageURI: "" });
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [error, setError] = useState("");

  function set(field: string, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit() {
    if (!form.name.trim()) { setError("Project name is required."); return; }
    setError(""); setStatus("idle");

    try {
      const hash = await registerProject(form.name.trim(), form.description.trim(), form.imageURI.trim());
      setStatus("success");
      setTimeout(() => router.push("/"), 2000);
    } catch (e: any) {
      setError(e.message ?? "Transaction failed");
      setStatus("error");
    }
  }

  const IPFS_TIPS = [
    "https://images.unsplash.com/photo-1498931299472-f7a63a5a1cfa?w=800",
    "https://images.unsplash.com/photo-1569163139394-de4e5f43e5ca?w=800",
    "ipfs://bafybeig...",
  ];

  return (
    <div className="container" style={{ paddingTop: 60, paddingBottom: 80, maxWidth: 680 }}>
      {/* Header */}
      <div style={{ marginBottom: 48 }}>
        <span style={{
          fontFamily: "var(--font-mono)", fontSize: 12,
          textTransform: "uppercase", letterSpacing: "0.1em",
          color: "var(--sage)",
        }}>
          ✦ Register on-chain
        </span>
        <h1 style={{
          fontFamily: "var(--font-display)", fontSize: "clamp(2rem, 5vw, 3.5rem)",
          fontWeight: 800, lineHeight: 1.1, marginTop: 8,
        }}>
          Submit your<br /><em style={{ color: "var(--gold)", fontStyle: "italic" }}>Project</em>
        </h1>
        <p style={{ color: "var(--slate)", marginTop: 12 }}>
          Your project will be registered on Base. You'll be set as the recipient
          — all donations and matching funds go directly to your wallet.
        </p>
      </div>

      {!userAddress ? (
        <div style={{
          background: "var(--cream)", border: "1.5px dashed var(--mist)",
          borderRadius: "var(--r-lg)", padding: 40, textAlign: "center",
        }}>
          <p style={{ fontFamily: "var(--font-display)", fontSize: "1.4rem", marginBottom: 8 }}>
            Connect your wallet first
          </p>
          <p style={{ color: "var(--slate)" }}>
            Your connected address will be the project recipient.
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          {/* Name */}
          <div>
            <label style={labelStyle}>Project Name *</label>
            <input
              className="input"
              placeholder="e.g. OpenPublicGoods, Greenpill Local Node…"
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              maxLength={80}
            />
            <span style={hintStyle}>{form.name.length}/80 characters</span>
          </div>

          {/* Description */}
          <div>
            <label style={labelStyle}>Description</label>
            <textarea
              className="input"
              placeholder="What does your project do? Who does it serve? Why does it matter?"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
              rows={5}
              maxLength={500}
            />
            <span style={hintStyle}>{form.description.length}/500 characters</span>
          </div>

          {/* Image URI */}
          <div>
            <label style={labelStyle}>Image URI</label>
            <input
              className="input"
              placeholder="https:// or ipfs://"
              value={form.imageURI}
              onChange={(e) => set("imageURI", e.target.value)}
            />
            <span style={hintStyle}>
              Use an IPFS URI or any public image URL.{" "}
              <span
                style={{ color: "var(--gold)", cursor: "pointer", textDecoration: "underline" }}
                onClick={() => set("imageURI", IPFS_TIPS[0])}
              >
                Use example
              </span>
            </span>
          </div>

          {/* Preview */}
          {form.imageURI && (
            <div style={{ borderRadius: "var(--r)", overflow: "hidden", maxHeight: 200 }}>
              <img
                src={form.imageURI}
                alt="preview"
                style={{ width: "100%", objectFit: "cover" }}
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
            </div>
          )}

          {/* Recipient notice */}
          <div style={{
            background: "rgba(90,122,90,0.1)", border: "1px solid rgba(90,122,90,0.25)",
            borderRadius: "var(--r)", padding: "14px 18px", fontSize: 13,
          }}>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--sage)", display: "block", marginBottom: 4, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Recipient address
            </span>
            <span style={{ fontFamily: "var(--font-mono)", wordBreak: "break-all" }}>
              {userAddress}
            </span>
          </div>

          {/* Error */}
          {error && (
            <div style={{
              padding: "12px 16px",
              background: "rgba(196,92,48,0.1)", border: "1px solid rgba(196,92,48,0.3)",
              borderRadius: "var(--r)", color: "var(--terracotta)", fontSize: 14,
            }}>
              {error}
            </div>
          )}

          {/* Success */}
          {status === "success" && (
            <div style={{
              padding: "16px 20px",
              background: "rgba(90,122,90,0.12)", border: "1px solid rgba(90,122,90,0.3)",
              borderRadius: "var(--r)", fontSize: 15,
            }}>
              🌱 Project registered! Redirecting to projects…
            </div>
          )}

          <button
            className="btn btn-primary"
            style={{ justifyContent: "center", fontSize: 16, padding: "16px" }}
            onClick={handleSubmit}
            disabled={txPending || !form.name.trim() || status === "success"}
          >
            {txPending ? "Broadcasting…" : "Register Project on Base ✦"}
          </button>
        </div>
      )}
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  fontFamily: "var(--font-mono)",
  fontSize: 12,
  textTransform: "uppercase" as const,
  letterSpacing: "0.08em",
  color: "var(--slate)",
  marginBottom: 8,
};

const hintStyle: React.CSSProperties = {
  display: "block",
  fontSize: 12,
  color: "var(--slate)",
  marginTop: 6,
};
