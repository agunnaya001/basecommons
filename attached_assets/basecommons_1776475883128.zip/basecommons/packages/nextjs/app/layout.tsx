import type { Metadata } from "next";
import "./globals.css";
import Nav from "../components/Nav";

export const metadata: Metadata = {
  title: "BaseCommons — Quadratic Funding on Base",
  description:
    "A democratic grant pool where broad community support outweighs concentrated wealth. Built on Base.",
  openGraph: {
    title: "BaseCommons",
    description: "Quadratic Funding, built for the commons. On Base.",
    siteName: "BaseCommons",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🌱</text></svg>" />
      </head>
      <body>
        {/*
          Scaffold-ETH 2 wraps this in <ScaffoldEthAppWithProviders>.
          In SE2 setup: wrap with your providers in _app.tsx or equivalent.
        */}
        <Nav />
        <main style={{ minHeight: "calc(100vh - 64px)" }}>
          {children}
        </main>
        <footer style={{
          borderTop: "1px solid var(--mist)",
          padding: "32px 24px",
          textAlign: "center",
          fontFamily: "var(--font-mono)",
          fontSize: 12,
          color: "var(--slate)",
        }}>
          BaseCommons · Quadratic Funding on Base · {new Date().getFullYear()}
        </footer>
      </body>
    </html>
  );
}
