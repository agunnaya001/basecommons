"use client";

/**
 * BaseCommons Web3 Providers
 *
 * Scaffold-ETH 2 already sets up RainbowKit + Wagmi for you.
 * If you're using the full SE2 scaffold, this file is handled by
 * packages/nextjs/app/providers.tsx in the SE2 template.
 *
 * This file is provided as a standalone setup if you're integrating
 * BaseCommons into a fresh Next.js app WITHOUT the full SE2 scaffold.
 *
 * Usage in layout.tsx:
 *   import { Providers } from "./providers";
 *   <Providers>{children}</Providers>
 */

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider, createConfig, http } from "wagmi";
import { base, baseSepolia, hardhat } from "wagmi/chains";
import { connectorsForWallets, RainbowKitProvider, darkTheme } from "@rainbow-me/rainbowkit";
import {
  injectedWallet,
  coinbaseWallet,
  metaMaskWallet,
  walletConnectWallet,
  rainbowWallet,
} from "@rainbow-me/rainbowkit/wallets";
import "@rainbow-me/rainbowkit/styles.css";

const PROJECT_ID = process.env.NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID ?? "";

const connectors = connectorsForWallets(
  [
    {
      groupName: "Recommended",
      wallets: [
        coinbaseWallet,   // Native Base wallet
        metaMaskWallet,
        rainbowWallet,
        walletConnectWallet,
        injectedWallet,
      ],
    },
  ],
  { appName: "BaseCommons", projectId: PROJECT_ID }
);

export const wagmiConfig = createConfig({
  chains: [base, baseSepolia, hardhat],
  connectors,
  transports: {
    [base.id]:        http(process.env.NEXT_PUBLIC_BASE_RPC_URL ?? "https://mainnet.base.org"),
    [baseSepolia.id]: http("https://sepolia.base.org"),
    [hardhat.id]:     http("http://127.0.0.1:8545"),
  },
  ssr: true,
});

const queryClient = new QueryClient();

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider
          theme={darkTheme({
            accentColor: "#c8972a",
            accentColorForeground: "#1a1208",
            borderRadius: "medium",
            fontStack: "system",
          })}
        >
          {children}
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}
