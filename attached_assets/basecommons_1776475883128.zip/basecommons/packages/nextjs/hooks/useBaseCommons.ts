import { useEffect, useState, useCallback } from "react";
import { usePublicClient, useWalletClient, useAccount } from "wagmi";
import { parseEther, formatEther } from "viem";
import { BASE_COMMONS_ABI, BASE_COMMONS_ADDRESS } from "../constants/contract";

/* ── Types ──────────────────────────────────────────────── */
export interface Project {
  id: bigint;
  name: string;
  description: string;
  imageURI: string;
  recipient: string;
  active: boolean;
  totalDonations: bigint;
  donorCount: bigint;
  estimatedMatch?: bigint;
}

export interface DonationEvent {
  donor: string;
  projectId: bigint;
  amount: bigint;
  cycleId: bigint;
  blockNumber: bigint;
  transactionHash: string;
}

/* ── Hook ───────────────────────────────────────────────── */
export function useBaseCommons() {
  const publicClient  = usePublicClient();
  const { data: walletClient } = useWalletClient();
  const { address: userAddress } = useAccount();

  const [projects, setProjects]               = useState<Project[]>([]);
  const [matchingPool, setMatchingPool]       = useState<bigint>(0n);
  const [cycleId, setCycleId]                 = useState<bigint>(1n);
  const [loading, setLoading]                 = useState(false);
  const [txPending, setTxPending]             = useState(false);
  const [error, setError]                     = useState<string | null>(null);

  /* ── Contract base config ─────────────────────────────── */
  const contractCfg = {
    address: BASE_COMMONS_ADDRESS as `0x${string}`,
    abi:     BASE_COMMONS_ABI,
  } as const;

  /* ── Fetch all data ───────────────────────────────────── */
  const refresh = useCallback(async () => {
    if (!publicClient) return;
    setLoading(true);
    setError(null);

    try {
      // Basic globals
      const [rawPool, rawCycle, rawCount] = await Promise.all([
        publicClient.readContract({ ...contractCfg, functionName: "matchingPool" }),
        publicClient.readContract({ ...contractCfg, functionName: "cycleId" }),
        publicClient.readContract({ ...contractCfg, functionName: "projectCount" }),
      ]) as [bigint, bigint, bigint];

      setMatchingPool(rawPool);
      setCycleId(rawCycle);

      const count = Number(rawCount);
      if (count === 0) {
        setProjects([]);
        setLoading(false);
        return;
      }

      // Fetch each project struct
      const projectCalls = Array.from({ length: count }, (_, i) => ({
        ...contractCfg,
        functionName: "projects" as const,
        args:         [BigInt(i + 1)] as [bigint],
      }));

      const rawProjects = await publicClient.multicall({ contracts: projectCalls });

      // Fetch estimated matching
      const [estIds, estAmounts] = await publicClient.readContract({
        ...contractCfg,
        functionName: "estimateMatching",
      }) as [bigint[], bigint[]];

      const matchMap = new Map<string, bigint>();
      estIds.forEach((id, i) => matchMap.set(id.toString(), estAmounts[i]));

      const parsed: Project[] = rawProjects.map((res, i) => {
        if (res.status !== "success" || !res.result) return null;
        const r = res.result as readonly [bigint, string, string, string, string, boolean, bigint, bigint];
        return {
          id:             r[0],
          name:           r[1],
          description:    r[2],
          imageURI:       r[3],
          recipient:      r[4],
          active:         r[5],
          totalDonations: r[6],
          donorCount:     r[7],
          estimatedMatch: matchMap.get(r[0].toString()) ?? 0n,
        };
      }).filter(Boolean) as Project[];

      setProjects(parsed);
    } catch (e: any) {
      setError(e.message ?? "Unknown error");
    } finally {
      setLoading(false);
    }
  }, [publicClient]);

  useEffect(() => { refresh(); }, [refresh]);

  /* ── Register Project ─────────────────────────────────── */
  const registerProject = useCallback(
    async (name: string, description: string, imageURI: string) => {
      if (!walletClient || !publicClient) throw new Error("Wallet not connected");
      setTxPending(true);
      try {
        const hash = await walletClient.writeContract({
          ...contractCfg,
          functionName: "registerProject",
          args:         [name, description, imageURI],
        });
        await publicClient.waitForTransactionReceipt({ hash });
        await refresh();
        return hash;
      } finally {
        setTxPending(false);
      }
    },
    [walletClient, publicClient, refresh]
  );

  /* ── Donate ───────────────────────────────────────────── */
  const donate = useCallback(
    async (projectId: bigint, amountEth: string) => {
      if (!walletClient || !publicClient) throw new Error("Wallet not connected");
      setTxPending(true);
      try {
        const hash = await walletClient.writeContract({
          ...contractCfg,
          functionName: "donate",
          args:         [projectId],
          value:        parseEther(amountEth),
        });
        await publicClient.waitForTransactionReceipt({ hash });
        await refresh();
        return hash;
      } finally {
        setTxPending(false);
      }
    },
    [walletClient, publicClient, refresh]
  );

  /* ── Fund Matching Pool ───────────────────────────────── */
  const fundMatchingPool = useCallback(
    async (amountEth: string) => {
      if (!walletClient || !publicClient) throw new Error("Wallet not connected");
      setTxPending(true);
      try {
        const hash = await walletClient.writeContract({
          ...contractCfg,
          functionName: "fundMatchingPool",
          value:        parseEther(amountEth),
        });
        await publicClient.waitForTransactionReceipt({ hash });
        await refresh();
        return hash;
      } finally {
        setTxPending(false);
      }
    },
    [walletClient, publicClient, refresh]
  );

  /* ── Distribute Matching ──────────────────────────────── */
  const distributeMatching = useCallback(async () => {
    if (!walletClient || !publicClient) throw new Error("Wallet not connected");
    setTxPending(true);
    try {
      const hash = await walletClient.writeContract({
        ...contractCfg,
        functionName: "distributeMatching",
      });
      await publicClient.waitForTransactionReceipt({ hash });
      await refresh();
      return hash;
    } finally {
      setTxPending(false);
    }
  }, [walletClient, publicClient, refresh]);

  /* ── Donation Events for a Project ───────────────────── */
  const getDonationEvents = useCallback(
    async (projectId: bigint): Promise<DonationEvent[]> => {
      if (!publicClient) return [];
      const logs = await publicClient.getLogs({
        address:   BASE_COMMONS_ADDRESS as `0x${string}`,
        event:     {
          type:   "event",
          name:   "Donation",
          inputs: [
            { type: "address", name: "donor",     indexed: true },
            { type: "uint256", name: "projectId", indexed: true },
            { type: "uint256", name: "amount",    indexed: false },
            { type: "uint256", name: "cycleId",   indexed: false },
          ],
        },
        args:      { projectId },
        fromBlock: 0n,
        toBlock:   "latest",
      });

      return logs.map((log) => ({
        donor:           log.args.donor as string,
        projectId:       log.args.projectId as bigint,
        amount:          log.args.amount as bigint,
        cycleId:         log.args.cycleId as bigint,
        blockNumber:     log.blockNumber,
        transactionHash: log.transactionHash,
      }));
    },
    [publicClient]
  );

  /* ── Off-chain QF estimate for a hypothetical donation ── */
  const estimateWithDonation = useCallback(
    (
      projects: Project[],
      targetProjectId: bigint,
      donorAddress: string,
      amountWei: bigint,
      currentPool: bigint
    ) => {
      // Simulate updated sqrtSums incorporating the new donation
      const sqrtSums: Map<string, bigint> = new Map();
      let totalSqrtSum = 0n;

      // For real usage we'd need per-donor amounts from chain; we approximate
      // using the aggregated totalDonations as a proxy for "one big donor"
      for (const p of projects) {
        const baseSqrt = sqrtBigInt(p.totalDonations * BigInt(1e9));
        const extra    = p.id === targetProjectId ? sqrtBigInt(amountWei * BigInt(1e9)) : 0n;
        const sum      = baseSqrt + extra;
        sqrtSums.set(p.id.toString(), sum);
        totalSqrtSum += sum;
      }

      if (totalSqrtSum === 0n) return new Map<string, bigint>();

      const result = new Map<string, bigint>();
      for (const p of projects) {
        const s = sqrtSums.get(p.id.toString()) ?? 0n;
        const matchAmount = (currentPool * s * s) / (totalSqrtSum * totalSqrtSum);
        result.set(p.id.toString(), matchAmount);
      }
      return result;
    },
    []
  );

  return {
    projects,
    matchingPool,
    cycleId,
    loading,
    txPending,
    error,
    userAddress,
    refresh,
    registerProject,
    donate,
    fundMatchingPool,
    distributeMatching,
    getDonationEvents,
    estimateWithDonation,
  };
}

/* ── Utility: integer sqrt for BigInt ───────────────────── */
export function sqrtBigInt(x: bigint): bigint {
  if (x <= 0n) return 0n;
  let z = (x + 1n) / 2n;
  let y = x;
  while (z < y) {
    y = z;
    z = (x / z + z) / 2n;
  }
  return y;
}
