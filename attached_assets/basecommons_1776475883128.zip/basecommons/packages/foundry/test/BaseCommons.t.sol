// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Test.sol";
import "../contracts/BaseCommons.sol";

contract BaseCommonsTest is Test {
    BaseCommons public bc;

    address admin   = address(0xA);
    address alice   = address(0xB);
    address bob     = address(0xC);
    address carol   = address(0xD);
    address project1Owner = address(0x1);
    address project2Owner = address(0x2);

    function setUp() public {
        bc = new BaseCommons(admin);
        vm.deal(alice, 10 ether);
        vm.deal(bob,   10 ether);
        vm.deal(carol, 10 ether);
        vm.deal(admin, 100 ether);
    }

    /* ── PROJECT REGISTRATION ───────────────────────────── */
    function test_registerProject() public {
        vm.prank(project1Owner);
        uint256 id = bc.registerProject("Greenpill", "Regen finance", "ipfs://abc");
        assertEq(id, 1);
        (
            uint256 pid,
            string memory name,
            ,
            ,
            address recipient,
            bool active,
            ,

        ) = bc.projects(1);
        assertEq(pid, 1);
        assertEq(name, "Greenpill");
        assertEq(recipient, project1Owner);
        assertTrue(active);
    }

    function test_registerProject_emptyName_reverts() public {
        vm.expectRevert("BaseCommons: empty name");
        bc.registerProject("", "desc", "ipfs://x");
    }

    /* ── DONATIONS ──────────────────────────────────────── */
    function test_donate_tracksUnique() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.prank(alice);
        bc.donate{value: 1 ether}(1);

        vm.prank(alice);
        bc.donate{value: 0.5 ether}(1);

        // alice counted once
        (, , , , , , , uint256 donorCount) = bc.projects(1);
        assertEq(donorCount, 1);
        assertEq(bc.donorAmounts(1, alice), 1.5 ether);
    }

    function test_donate_zeroReverts() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.expectRevert("BaseCommons: zero donation");
        bc.donate{value: 0}(1);
    }

    function test_donate_invalidProject_reverts() public {
        vm.expectRevert("BaseCommons: invalid project");
        vm.prank(alice);
        bc.donate{value: 1 ether}(999);
    }

    function test_donate_forwardsFunds() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        uint256 before = project1Owner.balance;
        vm.prank(alice);
        bc.donate{value: 1 ether}(1);

        assertEq(project1Owner.balance - before, 1 ether);
    }

    /* ── MATCHING POOL ──────────────────────────────────── */
    function test_fundMatchingPool() public {
        vm.prank(admin);
        bc.fundMatchingPool{value: 10 ether}();
        assertEq(bc.matchingPool(), 10 ether);
    }

    function test_receive_topsUpPool() public {
        vm.prank(alice);
        (bool ok,) = address(bc).call{value: 2 ether}("");
        assertTrue(ok);
        assertEq(bc.matchingPool(), 2 ether);
    }

    /* ── DISTRIBUTE MATCHING ────────────────────────────── */
    function test_distributeMatching_basic() public {
        // Register 2 projects
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc1", "");

        vm.prank(project2Owner);
        bc.registerProject("P2", "desc2", "");

        // Fund matching pool
        vm.prank(admin);
        bc.fundMatchingPool{value: 10 ether}();

        // Alice, Bob, Carol donate to P1 → 3 unique donors
        vm.prank(alice); bc.donate{value: 1 ether}(1);
        vm.prank(bob);   bc.donate{value: 1 ether}(1);
        vm.prank(carol); bc.donate{value: 1 ether}(1);

        // Only Alice donates to P2 → 1 unique donor
        vm.prank(alice); bc.donate{value: 1 ether}(2);

        uint256 p1Before = project1Owner.balance;
        uint256 p2Before = project2Owner.balance;

        vm.prank(admin);
        bc.distributeMatching();

        uint256 p1Gain = project1Owner.balance - p1Before;
        uint256 p2Gain = project2Owner.balance - p2Before;

        // P1 has 3 donors → should receive more matching than P2 (1 donor)
        assertGt(p1Gain, p2Gain);
        assertEq(bc.matchingPool(), 0);
        assertEq(bc.cycleId(), 2); // cycle incremented
    }

    function test_distributeMatching_onlyAdmin() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.prank(admin);
        bc.fundMatchingPool{value: 1 ether}();

        vm.expectRevert("BaseCommons: not admin");
        vm.prank(alice);
        bc.distributeMatching();
    }

    function test_distributeMatching_resetsState() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.prank(admin);
        bc.fundMatchingPool{value: 5 ether}();

        vm.prank(alice);
        bc.donate{value: 1 ether}(1);

        vm.prank(admin);
        bc.distributeMatching();

        // After reset: no donor amounts, donor count = 0
        assertEq(bc.donorAmounts(1, alice), 0);
        (, , , , , , , uint256 donorCount) = bc.projects(1);
        assertEq(donorCount, 0);
    }

    function test_estimateMatching_consistency() public {
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.prank(admin);
        bc.fundMatchingPool{value: 10 ether}();

        vm.prank(alice); bc.donate{value: 2 ether}(1);
        vm.prank(bob);   bc.donate{value: 1 ether}(1);

        (uint256[] memory ids, uint256[] memory amounts) = bc.estimateMatching();
        assertEq(ids[0], 1);
        // Single project should receive entire pool
        assertEq(amounts[0], 10 ether);
    }

    /* ── SQRT (internal, tested via distribution) ────────── */
    function test_sqrtPrecision_noRevert() public {
        // Ensure large values don't overflow
        vm.prank(project1Owner);
        bc.registerProject("P1", "desc", "");

        vm.prank(admin);
        bc.fundMatchingPool{value: 50 ether}();

        vm.prank(alice);
        bc.donate{value: 50 ether}(1);

        vm.prank(admin);
        bc.distributeMatching(); // should not revert
    }
}
