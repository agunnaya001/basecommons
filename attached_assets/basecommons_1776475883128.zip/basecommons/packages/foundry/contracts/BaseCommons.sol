// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title BaseCommons
 * @notice Quadratic Funding Pool — built for Base
 * @dev Projects register on-chain, donors contribute ETH, admin distributes
 *      matching funds using the quadratic funding formula (sum of sqrt)^2
 */
contract BaseCommons {
    /* ──────────────────────────────────────────────────────
       STRUCTS
    ────────────────────────────────────────────────────── */
    struct Project {
        uint256 id;
        string  name;
        string  description;
        string  imageURI;
        address payable recipient;
        bool    active;
        uint256 totalDonations;   // raw ETH donated (wei)
        uint256 donorCount;       // unique donors this cycle
    }

    /* ──────────────────────────────────────────────────────
       STATE
    ────────────────────────────────────────────────────── */
    address public immutable admin;

    uint256 public projectCount;
    uint256 public matchingPool;
    uint256 public cycleId;

    // projectId => Project
    mapping(uint256 => Project) public projects;

    // projectId => donor => amount donated this cycle
    mapping(uint256 => mapping(address => uint256)) public donorAmounts;

    // projectId => list of donor addresses (for iteration)
    mapping(uint256 => address[]) private _donors;

    // projectId => donor => alreadyTracked (to avoid duplication in array)
    mapping(uint256 => mapping(address => bool)) private _donorTracked;

    /* ──────────────────────────────────────────────────────
       EVENTS
    ────────────────────────────────────────────────────── */
    event ProjectRegistered(
        uint256 indexed projectId,
        address indexed recipient,
        string  name,
        string  imageURI
    );

    event Donation(
        address indexed donor,
        uint256 indexed projectId,
        uint256 amount,
        uint256 cycleId
    );

    event MatchingPoolFunded(address indexed funder, uint256 amount);

    event MatchingDistributed(
        uint256 indexed cycleId,
        uint256 totalPool,
        uint256 projectCount
    );

    event MatchingAllocated(
        uint256 indexed cycleId,
        uint256 indexed projectId,
        uint256 amount
    );

    /* ──────────────────────────────────────────────────────
       MODIFIERS
    ────────────────────────────────────────────────────── */
    modifier onlyAdmin() {
        require(msg.sender == admin, "BaseCommons: not admin");
        _;
    }

    /* ──────────────────────────────────────────────────────
       CONSTRUCTOR
    ────────────────────────────────────────────────────── */
    constructor(address _admin) {
        require(_admin != address(0), "BaseCommons: zero admin");
        admin    = _admin;
        cycleId  = 1;
    }

    /* ──────────────────────────────────────────────────────
       PROJECT REGISTRATION
    ────────────────────────────────────────────────────── */
    /**
     * @notice Register a new project. Caller becomes the recipient.
     * @param name        Short project name
     * @param description Project description
     * @param imageURI    IPFS/HTTP URI for project image
     */
    function registerProject(
        string calldata name,
        string calldata description,
        string calldata imageURI
    ) external returns (uint256 projectId) {
        require(bytes(name).length > 0, "BaseCommons: empty name");

        projectId = ++projectCount;

        projects[projectId] = Project({
            id:             projectId,
            name:           name,
            description:    description,
            imageURI:       imageURI,
            recipient:      payable(msg.sender),
            active:         true,
            totalDonations: 0,
            donorCount:     0
        });

        emit ProjectRegistered(projectId, msg.sender, name, imageURI);
    }

    /* ──────────────────────────────────────────────────────
       DONATIONS
    ────────────────────────────────────────────────────── */
    /**
     * @notice Donate ETH to a project.
     * @param projectId  The project to fund
     */
    function donate(uint256 projectId) external payable {
        require(msg.value > 0,          "BaseCommons: zero donation");
        require(projectId > 0 && projectId <= projectCount, "BaseCommons: invalid project");
        require(projects[projectId].active, "BaseCommons: project inactive");

        Project storage project = projects[projectId];

        // Track unique donors
        if (!_donorTracked[projectId][msg.sender]) {
            _donorTracked[projectId][msg.sender] = true;
            _donors[projectId].push(msg.sender);
            project.donorCount++;
        }

        donorAmounts[projectId][msg.sender] += msg.value;
        project.totalDonations             += msg.value;

        // Forward donation directly to recipient
        project.recipient.transfer(msg.value);

        emit Donation(msg.sender, projectId, msg.value, cycleId);
    }

    /* ──────────────────────────────────────────────────────
       MATCHING POOL FUNDING
    ────────────────────────────────────────────────────── */
    /**
     * @notice Fund the matching pool explicitly.
     */
    function fundMatchingPool() external payable {
        require(msg.value > 0, "BaseCommons: zero fund");
        matchingPool += msg.value;
        emit MatchingPoolFunded(msg.sender, msg.value);
    }

    /**
     * @notice Fallback — any ETH sent to the contract tops up the pool.
     */
    receive() external payable {
        matchingPool += msg.value;
        emit MatchingPoolFunded(msg.sender, msg.value);
    }

    /* ──────────────────────────────────────────────────────
       QUADRATIC FUNDING DISTRIBUTION
    ────────────────────────────────────────────────────── */
    /**
     * @notice Admin triggers matching fund distribution using QF formula.
     * @dev    QF share = (sqrtSum_i / totalSqrtSum)^2 * pool
     *         where sqrtSum_i = sum of sqrt(donation_j) for each donor j of project i.
     *
     *         We scale by 1e9 before sqrt to retain 9 decimal places of precision
     *         in fixed-point integer arithmetic, then normalise at the end.
     */
    function distributeMatching() external onlyAdmin {
        require(matchingPool > 0,    "BaseCommons: empty pool");
        require(projectCount > 0,    "BaseCommons: no projects");

        uint256 pool          = matchingPool;
        uint256 currentCycle  = cycleId;

        // ── 0. CEI: zero the pool immediately to prevent reentrancy ──
        matchingPool = 0;

        // ── 1. Compute sqrtSum per project ──────────────────
        // sqrtSums[i] = sum of isqrt(amount * 1e9) for each donor of project (i+1)
        uint256[] memory sqrtSums = new uint256[](projectCount);
        uint256 totalSqrtSum      = 0;

        for (uint256 pid = 1; pid <= projectCount; pid++) {
            address[] storage donors = _donors[pid];
            uint256 pSqrtSum = 0;

            for (uint256 d = 0; d < donors.length; d++) {
                uint256 amt = donorAmounts[pid][donors[d]];
                if (amt > 0) {
                    // Scale up to preserve precision, then integer sqrt
                    pSqrtSum += _sqrt(amt * 1e9);
                }
            }

            sqrtSums[pid - 1] = pSqrtSum;
            totalSqrtSum      += pSqrtSum;
        }

        // ── 2. Distribute pool ──────────────────────────────
        if (totalSqrtSum == 0) {
            // No contributions: return pool to admin
            payable(admin).transfer(pool);
            _resetCycle();
            return;
        }

        uint256 distributed = 0;

        for (uint256 pid = 1; pid <= projectCount; pid++) {
            uint256 sqrtSum = sqrtSums[pid - 1];
            if (sqrtSum == 0) continue;
            if (!projects[pid].active) continue;

            // share = (sqrtSum / totalSqrtSum)^2 * pool
            // = sqrtSum^2 * pool / totalSqrtSum^2
            // Use mulDiv-style to avoid overflow:
            // amount = pool * sqrtSum^2 / totalSqrtSum^2
            uint256 numerator   = sqrtSum * sqrtSum;        // safe: sqrtSums are bounded
            uint256 denominator = totalSqrtSum * totalSqrtSum;

            uint256 matchAmount = (pool * numerator) / denominator;

            if (matchAmount > 0) {
                distributed += matchAmount;
                projects[pid].recipient.transfer(matchAmount);
                emit MatchingAllocated(currentCycle, pid, matchAmount);
            }
        }

        // ── 3. Return any dust to admin (rounding remainder) ─
        uint256 remainder = pool - distributed;
        if (remainder > 0) {
            payable(admin).transfer(remainder);
        }

        matchingPool = 0; // already zeroed above; explicit for clarity
        emit MatchingDistributed(currentCycle, pool, projectCount);

        // ── 4. Reset for next cycle ──────────────────────────
        _resetCycle();
    }

    /* ──────────────────────────────────────────────────────
       VIEW HELPERS
    ────────────────────────────────────────────────────── */
    /**
     * @notice Returns all project IDs (1..projectCount).
     */
    function getAllProjectIds() external view returns (uint256[] memory ids) {
        ids = new uint256[](projectCount);
        for (uint256 i = 0; i < projectCount; i++) {
            ids[i] = i + 1;
        }
    }

    /**
     * @notice Returns the donors array for a project (for off-chain reading).
     */
    function getDonors(uint256 projectId) external view returns (address[] memory) {
        return _donors[projectId];
    }

    /**
     * @notice Off-chain quadratic match estimator.
     * @dev    Returns (matchAmounts[], projectIds[]) representing the distribution
     *         if distributeMatching() were called RIGHT NOW with the current pool.
     */
    function estimateMatching()
        external
        view
        returns (uint256[] memory ids, uint256[] memory amounts)
    {
        ids     = new uint256[](projectCount);
        amounts = new uint256[](projectCount);

        if (matchingPool == 0 || projectCount == 0) return (ids, amounts);

        uint256[] memory sqrtSums = new uint256[](projectCount);
        uint256 totalSqrtSum      = 0;

        for (uint256 pid = 1; pid <= projectCount; pid++) {
            address[] storage donors = _donors[pid];
            uint256 pSqrtSum = 0;
            for (uint256 d = 0; d < donors.length; d++) {
                uint256 amt = donorAmounts[pid][donors[d]];
                if (amt > 0) pSqrtSum += _sqrt(amt * 1e9);
            }
            sqrtSums[pid - 1] = pSqrtSum;
            totalSqrtSum      += pSqrtSum;
            ids[pid - 1]       = pid;
        }

        if (totalSqrtSum == 0) return (ids, amounts);

        uint256 pool = matchingPool;
        for (uint256 pid = 1; pid <= projectCount; pid++) {
            uint256 s = sqrtSums[pid - 1];
            if (s == 0) continue;
            uint256 num   = s * s;
            uint256 denom = totalSqrtSum * totalSqrtSum;
            amounts[pid - 1] = (pool * num) / denom;
        }
    }

    /* ──────────────────────────────────────────────────────
       INTERNAL
    ────────────────────────────────────────────────────── */
    /**
     * @dev Babylonian integer square root (floor).
     */
    function _sqrt(uint256 x) internal pure returns (uint256 y) {
        if (x == 0) return 0;
        uint256 z = (x + 1) / 2;
        y = x;
        while (z < y) {
            y = z;
            z = (x / z + z) / 2;
        }
    }

    /**
     * @dev Reset donor tracking for next cycle.
     */
    function _resetCycle() internal {
        for (uint256 pid = 1; pid <= projectCount; pid++) {
            address[] storage donors = _donors[pid];
            for (uint256 d = 0; d < donors.length; d++) {
                delete donorAmounts[pid][donors[d]];
                delete _donorTracked[pid][donors[d]];
            }
            delete _donors[pid];
            projects[pid].totalDonations = 0;
            projects[pid].donorCount     = 0;
        }
        cycleId++;
    }
}
