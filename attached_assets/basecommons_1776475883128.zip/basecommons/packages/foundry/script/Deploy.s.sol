// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Script.sol";
import "../contracts/BaseCommons.sol";

contract DeployBaseCommons is Script {
    function run() external {
        // Admin defaults to the deployer. Override by setting ADMIN_ADDRESS env var.
        address adminAddr = vm.envOr("ADMIN_ADDRESS", msg.sender);

        vm.startBroadcast();

        BaseCommons bc = new BaseCommons(adminAddr);

        console.log("BaseCommons deployed at:", address(bc));
        console.log("Admin:", adminAddr);

        vm.stopBroadcast();
    }
}
